package com.nikhil.motionstudio.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.withFrameNanos
import com.nikhil.motionstudio.engine.Composition
import com.nikhil.motionstudio.engine.Keyframe
import com.nikhil.motionstudio.engine.interpolateLinear
import kotlin.math.roundToInt

// Phase 1 placeholder: one square whose X position is driven by two hardcoded keyframes.
private val demoXKeys = listOf(Keyframe(0, 100f), Keyframe(89, 1500f))
private val demoYKeys = listOf(Keyframe(0, 400f), Keyframe(89, 400f))
private const val DEMO_SQUARE_SIZE = 200f

@Composable
fun PreviewScreen(comp: Composition) {
    var frame by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(false) }

    LaunchedEffect(playing) {
        if (!playing) return@LaunchedEffect
        var previous = withFrameNanos { it }
        var accumulator = 0.0
        while (true) {
            val now = withFrameNanos { it }
            accumulator += (now - previous) / 1e9 * comp.frameRate
            previous = now
            val step = accumulator.toInt()
            if (step > 0) {
                accumulator -= step
                frame = (frame + step) % comp.durationFrames
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("${comp.name}  ${comp.width}x${comp.height}  ${comp.frameRate} fps")

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(comp.width / comp.height.toFloat())
                .background(Color.Black)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val scale = size.width / comp.width
                val x = interpolateLinear(demoXKeys, frame.toFloat())
                val y = interpolateLinear(demoYKeys, frame.toFloat())
                drawRect(
                    color = Color(0xFF4FC3F7),
                    topLeft = Offset(x * scale, y * scale),
                    size = Size(DEMO_SQUARE_SIZE * scale, DEMO_SQUARE_SIZE * scale)
                )
            }
        }

        Text("Frame $frame / ${comp.lastFrame}  (${"%.2f".format(frame / comp.frameRate.toDouble())} s)")

        Slider(
            value = frame.toFloat(),
            onValueChange = { frame = it.roundToInt() },
            valueRange = 0f..comp.lastFrame.toFloat()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { playing = !playing }) {
                Text(if (playing) "Pause" else "Play")
            }
            Button(onClick = { playing = false; frame = 0 }) {
                Text("Reset")
            }
        }
    }
}
