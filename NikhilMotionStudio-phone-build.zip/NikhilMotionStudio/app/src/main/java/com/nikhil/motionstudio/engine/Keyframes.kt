package com.nikhil.motionstudio.engine

/** A single keyframe on a scalar property. */
data class Keyframe(val frame: Int, val value: Float)

/**
 * Linear interpolation between keyframes. Values before the first key and after
 * the last key are clamped. Keys must be sorted by frame.
 * Phase 1 only supports linear easing; bezier curves come in Phase 3.
 */
fun interpolateLinear(keys: List<Keyframe>, frame: Float): Float {
    if (keys.isEmpty()) return 0f
    if (frame <= keys.first().frame) return keys.first().value
    if (frame >= keys.last().frame) return keys.last().value

    for (i in 0 until keys.size - 1) {
        val a = keys[i]
        val b = keys[i + 1]
        if (frame >= a.frame && frame <= b.frame) {
            val t = (frame - a.frame) / (b.frame - a.frame).toFloat()
            return a.value + (b.value - a.value) * t
        }
    }
    return keys.last().value
}
