package com.nikhil.motionstudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import com.nikhil.motionstudio.engine.Composition
import com.nikhil.motionstudio.ui.PreviewScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    PreviewScreen(
                        Composition(
                            name = "Demo Comp",
                            width = 1920,
                            height = 1080,
                            frameRate = 30,
                            durationFrames = 90
                        )
                    )
                }
            }
        }
    }
}
