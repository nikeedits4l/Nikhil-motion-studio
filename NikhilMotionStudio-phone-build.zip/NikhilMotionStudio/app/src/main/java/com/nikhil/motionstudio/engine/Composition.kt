package com.nikhil.motionstudio.engine

/** A project composition: canvas size, frame rate and duration. */
data class Composition(
    val name: String,
    val width: Int,
    val height: Int,
    val frameRate: Int,
    val durationFrames: Int,
) {
    init {
        require(width > 0 && height > 0) { "Composition size must be positive" }
        require(frameRate > 0) { "Frame rate must be positive" }
        require(durationFrames > 0) { "Duration must be at least one frame" }
    }

    val lastFrame: Int get() = durationFrames - 1
    val durationSeconds: Double get() = durationFrames.toDouble() / frameRate
}
