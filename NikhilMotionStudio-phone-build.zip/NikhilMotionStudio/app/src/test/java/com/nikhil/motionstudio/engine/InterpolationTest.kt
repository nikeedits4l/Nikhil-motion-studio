package com.nikhil.motionstudio.engine

import org.junit.Assert.assertEquals
import org.junit.Test

class InterpolationTest {
    private val keys = listOf(Keyframe(0, 0f), Keyframe(10, 100f))

    @Test fun midpointIsLinear() = assertEquals(50f, interpolateLinear(keys, 5f), 0.001f)
    @Test fun clampsBeforeFirstKey() = assertEquals(0f, interpolateLinear(keys, -5f), 0.001f)
    @Test fun clampsAfterLastKey() = assertEquals(100f, interpolateLinear(keys, 99f), 0.001f)
    @Test fun emptyKeysReturnZero() = assertEquals(0f, interpolateLinear(emptyList(), 3f), 0.001f)
}
